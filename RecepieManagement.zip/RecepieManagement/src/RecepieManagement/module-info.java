module com.example.recepiemanagement {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;
    requires okhttp3;
    requires org.json;
    requires com.google.gson;

    opens RecepieManagement.Adapters to com.google.gson;
    opens RecepieManagement to javafx.fxml;
    exports RecepieManagement;

    opens RecepieManagement.Controllers to javafx.fxml;
    exports RecepieManagement.Controllers;
    exports RecepieManagement.Classes; // add this line
//    opens RecepieManagement.views to javafx.fxml;
//    exports RecepieManagement.views;
}