package RecepieManagement;
import RecepieManagement.Classes.user;
import RecepieManagement.Controllers.BrowserService;
import javafx.application.Application;
import javafx.application.HostServices;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;

public class mainApplication extends Application implements BrowserService {

    private static user currentUser;

    public static void setCurrentUser(user user) {
        currentUser = user;

    }

    public static user getCurrentUser() {
        return currentUser;
    }

    @Override
    public void openUrl(String url) {
        HostServices hostServices = getHostServices();
        hostServices.showDocument(url);
    }

    @Override
    public void start(Stage stage) throws IOException {
       FXMLLoader fxmlLoader = new FXMLLoader(mainApplication.class.getResource
               ("views/LOGIN_and_REGISTER/loginPage.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setResizable(false);
        stage.setTitle("RecipeManagement!");


        Image image = new Image(Objects.requireNonNull
                (mainApplication.class.getResourceAsStream("RLogo.png"))
                , 300, 300, true, true);

        stage.getIcons().add(image);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }

}