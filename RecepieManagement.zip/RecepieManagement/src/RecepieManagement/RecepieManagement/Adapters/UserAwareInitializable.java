package RecepieManagement.Adapters;

import RecepieManagement.Classes.user;
import javafx.fxml.Initializable;

public interface UserAwareInitializable extends Initializable {
    void setCurrentUser(user currentUser);
}