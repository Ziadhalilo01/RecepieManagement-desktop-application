package RecepieManagement.Adapters;

import RecepieManagement.Classes.RecipeSearchResponse;
import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

    public class RecipeSearchResponseTypeAdapter extends TypeAdapter<RecipeSearchResponse> {
    @Override
    public RecipeSearchResponse read(JsonReader in) throws IOException {
        RecipeSearchResponse searchResponse = new RecipeSearchResponse();
        List<RecipeSearchResponse.Hit> hits = new ArrayList<>();
        in.beginObject();
        while (in.hasNext()) {
            String name = in.nextName();
            if (name.equals("hits")) {
                in.beginArray();
                while (in.hasNext()) {
                    RecipeSearchResponse.Hit hit = new RecipeSearchResponse.Hit();
                    in.beginObject();
                    while (in.hasNext()) {
                        String hitName = in.nextName();
                        if (hitName.equals("recipe")) {
                            hit.recipy = new RecipeSearchResponse.Recipy();
                            in.beginObject();
                            while (in.hasNext()) {
                                String recipeName = in.nextName();
                                if (recipeName.equals("label")) {
                                    hit.recipy.label = in.nextString();
                                } else if (recipeName.equals("image")) {
                                    hit.recipy.image = in.nextString();
                                } else if (recipeName.equals("url")) {
                                    hit.recipy.url = in.nextString();
                                } else if (recipeName.equals("dietLabels")) {
                                    hit.recipy.dietLabels = readStringArray(in);
                                } else if (recipeName.equals("healthLabels")) {
                                    hit.recipy.healthLabels = readStringArray(in);
                                } else if (recipeName.equals("cautions")) {
                                    hit.recipy.cautions = readStringArray(in);
                                } else if (recipeName.equals("ingredients")) {
                                    hit.recipy.ingredients = readIngredients(in);
                                } else if (recipeName.equals("calories")) {
                                    hit.recipy.calories = in.nextDouble();
                                } else if (recipeName.equals("totalWeight")) {
                                    hit.recipy.totalWeight = in.nextDouble();
                                } else {
                                    in.skipValue();
                                }
                            }
                            in.endObject();
                        } else {
                            in.skipValue();
                        }
                    }
                    in.endObject();
                    hits.add(hit);
                }
                in.endArray();
                searchResponse.hits = hits;
            } else {
                in.skipValue();
            }
        }
        in.endObject();
        return searchResponse;
    }

    @Override
    public void write(JsonWriter out, RecipeSearchResponse value) throws IOException {
        // Not implemented
    }

    private List<String> readStringArray(JsonReader in) throws IOException {
        List<String> stringArray = new ArrayList<>();
        in.beginArray();
        while (in.hasNext()) {
            stringArray.add(in.nextString());
        }
        in.endArray();
        return stringArray;
    }

    private List<RecipeSearchResponse.Recipy.Ingredient> readIngredients(JsonReader in) throws IOException {
        List<RecipeSearchResponse.Recipy.Ingredient> ingredients = new ArrayList<>();
        in.beginArray();
        while (in.hasNext()) {
            RecipeSearchResponse.Recipy.Ingredient ingredient = new RecipeSearchResponse.Recipy.Ingredient();
            in.beginObject();
            while (in.hasNext()) {
                String ingredientName = in.nextName();
                if (ingredientName.equals("text")) {
                    ingredient.text = in.nextString();
                } else if (ingredientName.equals("weight")) {
                    ingredient.weight = in.nextDouble();
                } else {
                    in.skipValue();
                }
            }
            in.endObject();
            ingredients.add(ingredient);
        }
        in.endArray();
        return ingredients;
    }
}
