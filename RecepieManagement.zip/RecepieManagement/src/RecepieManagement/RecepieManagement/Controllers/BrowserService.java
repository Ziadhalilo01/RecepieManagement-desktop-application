package RecepieManagement.Controllers;

public interface BrowserService {
    void openUrl(String url);
}
