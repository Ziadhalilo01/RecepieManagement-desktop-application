package RecepieManagement.Controllers;



import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.Window;

public class CustomTitleBarController {

    @FXML
    private Button minimizeButton;

    @FXML
    private Button maximizeButton;

    @FXML
    private Button closeButton;

    private Stage getStage() {
        Window window = closeButton.getScene().getWindow();
        return (Stage) window;
    }

    @FXML
    private void minimizeWindow() {
        getStage().setIconified(true);
    }

    @FXML
    private void maximizeWindow() {
        Stage stage = getStage();
        if (stage.isMaximized()) {
            stage.setMaximized(false);
        } else {
            stage.setMaximized(true);
        }
    }

    @FXML
    private void closeWindow() {
        getStage().close();
    }
}
