package RecepieManagement.Controllers;
import com.google.gson.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class DietController implements Initializable{
    @FXML
    private TextField searchTextField;

    @FXML
    private VBox searchResultsBox;

    private BrowserService browserService;

    public void setBrowserService(BrowserService browserService) {
        this.browserService = browserService;
    }

    @FXML
    private void searchRecipes() {
        System.out.println("hello");
        String query = searchTextField.getText().trim();

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url("https://edamam-recipe-search.p.rapidapi.com/search?q=" + query)
                .get()
                .addHeader("X-RapidAPI-Key", "70a7e9d646msh1390870405bd41cp1fe75ajsn102d61a49923")
                .addHeader("X-RapidAPI-Host", "edamam-recipe-search.p.rapidapi.com")
                .build();

        try {
            Response response = client.newCall(request).execute();
            String responseBody = response.body().string();
            displayResults(responseBody);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void displayResults(String jsonString) {
        searchResultsBox.getChildren().clear();

        JsonObject jsonObject = JsonParser.parseString(jsonString).getAsJsonObject();
        JsonArray hits = jsonObject.getAsJsonArray("hits");

        for (JsonElement hit : hits) {
            JsonObject recipe = hit.getAsJsonObject().get("recipe").getAsJsonObject();

            String imageUrl = recipe.get("image").getAsString();
            String sourceUrl = recipe.get("url").getAsString();
            String source = recipe.get("source").getAsString();

            ImageView imageView = new ImageView(new Image(imageUrl));
            imageView.setFitWidth(100);
            imageView.setPreserveRatio(true);

            Hyperlink sourceLink = new Hyperlink(sourceUrl);
            sourceLink.setOnAction(e -> {
                if (browserService != null) {
                    browserService.openUrl(sourceLink.getText());
                }
            });
            Label sourceLabel = new Label("Source: " + source);

            VBox recipeBox = new VBox(5, imageView, sourceLink, sourceLabel);
            recipeBox.getStyleClass().add("recipe-box");

            recipeBox.setStyle("-fx-padding: 10; -fx-text-fill:white; -fx-border-color: rgb(40,40,40); -fx-border-width: 1; -fx-background-color: rgb(40,40,40)");


            imageView.setFitHeight(100);
            imageView.setFitWidth(100);
            searchResultsBox.getChildren().add(recipeBox);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        searchRecipes();
    }
}