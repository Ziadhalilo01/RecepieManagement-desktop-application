package RecepieManagement.Controllers;
import RecepieManagement.Adapters.UserAwareInitializable;
import RecepieManagement.Classes.Recipe;
import RecepieManagement.Classes.user;
import RecepieManagement.DBConnection.DBHandler;
import RecepieManagement.mainApplication;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class RecipyCardController {
    @FXML
    private ImageView image_recipy;

    private boolean isStarFilled = false;
    @FXML
    private GridPane Lays;

    @FXML
    private Label recipy_cookingtime;

    @FXML
    private Label recipy_name;

    @FXML
    private Button view_recipe_button;

    @FXML
    private Button star_button;

    Recipe recipy;

    user users = new user();
    private YourFavoritesController yourFavoritesController;

    public void openFavoritesView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/RecepieManagement/FavoritesScene.fxml"));
            Parent root = loader.load();


            System.out.println("OpenFavoritesView - User object: " + users);
            System.out.println("OpenFavoritesView - User ID: " + users.getUsername());

            YourFavoritesController controller = new YourFavoritesController(mainApplication.getCurrentUser());

            loader.setController(controller);


            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




    public void setYourFavoritesController(YourFavoritesController yourFavoritesController) {
        this.yourFavoritesController = yourFavoritesController;
    }

    public RecipyCardController() {
    }


public void setUsers(user users) {
        System.out.println("wwwwwwwwwww    "+users.getUser_id());
    this.users = users;
}




    public GridPane createRecipeCard(Recipe recipe) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/RecepieManagement/RecipyCard.fxml"));
        GridPane recipyCard = null;
        try {
            recipyCard = loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        RecipyCardController controller = loader.getController();
        controller.setRecipy(recipe, users);
        controller.setYourFavoritesController(yourFavoritesController);
        return recipyCard;
    }


    public void setRecipy(Recipe recipy,user users) {
        System.out.println("IN setRecipy , RecipyCardController - Users object: " + users);
        System.out.println(" IN setRecipy ,RecipyCardController - User ID: " + users.getUser_id());
        System.out.println(users.getUser_id());
        this.recipy = recipy;
        this.users = users;
        ByteArrayInputStream bis = new ByteArrayInputStream(recipy.getRecipe_image());
        Image image = new Image(bis);
        image_recipy.setImage(image);

        recipy_name.setText(recipy.getRecipe_name());
        recipy_cookingtime.setText(Integer.toString(recipy.getCooking_time()));

        DBHandler db = DBHandler.getInstance();
        isStarFilled = db.isRecipeInFavorites(users.getUser_id(), recipy.getRecipe_id());
        if (isStarFilled) {
            star_button.setStyle("-fx-background-color: yellow, yellow;");
        } else {
            star_button.setStyle("-fx-background-color: white, rgb(40,40,40);");
        }

        star_button.setOnAction(event -> {
            if (isStarFilled) {
                star_button.setStyle("-fx-background-color: white, rgb(40,40,40);");
                db.removeFavorite(users.getUser_id(), recipy.getRecipe_id());
                if (yourFavoritesController != null) {
                    yourFavoritesController.updateFavorites(recipy, false);
                }
                isStarFilled = false;
            } else {
                star_button.setStyle("-fx-background-color: yellow, yellow;");
                db.addFavorite(users.getUser_id(), recipy.getRecipe_id());
                if (yourFavoritesController != null) {
                    yourFavoritesController.updateFavorites(recipy, true);
                }
                isStarFilled = true;
            }
        });


            view_recipe_button.setOnAction(event -> { try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/RecepieManagement/RecipeDetail.fxml"));
            Parent root = loader.load();
            RecipeDetailController controller = loader.getController();
            controller.setRecipeInfo(recipy.getInstructions());
            System.out.println(recipy.getInstructions());
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
        });


    }
}