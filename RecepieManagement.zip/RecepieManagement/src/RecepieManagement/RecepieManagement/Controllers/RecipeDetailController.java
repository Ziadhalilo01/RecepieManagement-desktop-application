package RecepieManagement.Controllers;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class RecipeDetailController {
    @FXML
    Label recipeInfo1;
    @FXML
    Label recipeInfo2;
    @FXML
    Label recipeInfo3;
    @FXML
    Label recipeInfo4;
    @FXML
    Label recipeInfo5;
    @FXML
    Label recipeInfo6;

    private String recipeInformation;

    @FXML
    public void setRecipeInfo(String info) {
        Label[] recipeInfo = {recipeInfo1, recipeInfo2, recipeInfo3, recipeInfo4, recipeInfo5, recipeInfo6};
        this.recipeInformation = info;
        String result = "";
        int count = 0;
        for(int i = 0; i < recipeInformation.length(); i++) {

            if('$' == recipeInformation.charAt(i)) {

                recipeInfo[count].setText(result.substring(1));
                result = "";
                count++;

                if(count == recipeInfo.length) {
                    break;
                }

            }

            result += recipeInformation.charAt(i);

        }
    }

}
