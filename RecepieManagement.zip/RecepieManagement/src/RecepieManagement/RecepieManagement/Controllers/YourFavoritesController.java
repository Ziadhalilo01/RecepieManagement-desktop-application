package RecepieManagement.Controllers;
import RecepieManagement.Adapters.UserAwareInitializable;
import RecepieManagement.Classes.Recipe;
import RecepieManagement.Classes.user;
import RecepieManagement.DBConnection.DBHandler;
import RecepieManagement.mainApplication;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class YourFavoritesController implements UserAwareInitializable {

    @FXML
    HBox FavLayout;

    private user currentUser;

    private List<Recipe> favoriteRecipes;

    public YourFavoritesController() {
    }
    public YourFavoritesController(user currentUser) {
        this.currentUser = currentUser;
    }
        @Override
        public void initialize(URL location, ResourceBundle resources) {
            setCurrentUser(mainApplication.getCurrentUser());

        }

    private List<Recipe> getFavoriteRecipesFromDatabase(user currentUser) {
        List<Recipe> favoriteRecipes;

        DBHandler db = DBHandler.getInstance();

        favoriteRecipes = db.getFavoriteRecipesForUser(currentUser.getUser_id());

        return favoriteRecipes;
    }
    public void loadFavoriteRecipes() {
        List<Recipe> favoriteRecipes = getFavoriteRecipesFromDatabase(currentUser);


        for (Recipe recipe : favoriteRecipes) {
            GridPane recipeCard = createRecipeCard(recipe);
            FavLayout.getChildren().add(recipeCard);
        }
    }

    public GridPane createRecipeCard(Recipe recipe) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/RecepieManagement/RecipyCard.fxml"));
        GridPane recipyCard = null;
        try {
            recipyCard = loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        RecipyCardController controller = loader.getController();
        controller.setRecipy(recipe, currentUser);
        controller.setYourFavoritesController(this);
        return recipyCard;
    }



    public void updateFavorites(Recipe recipe, boolean isAdded) {
        GridPane recipyCard = createRecipeCard(recipe);

        if (isAdded) {
            FavLayout.getChildren().add(recipyCard);
        } else {
            for (Node node : FavLayout.getChildren()) {
                if (node instanceof GridPane) {
                    GridPane gridPane = (GridPane) node;
                    Label nameLabel = (Label) gridPane.lookup("#recipy_name");
                    if (nameLabel != null && nameLabel.getText().equals(recipe.getRecipe_name())) {
                        FavLayout.getChildren().remove(gridPane);
                        break;
                    }
                }
            }
        }
    }

    @Override
    public void setCurrentUser(user currentUser) {
        this.currentUser = currentUser;
        System.out.println("IN setCurrentUser, YourFavoritesController - User object: " + this.currentUser);
        System.out.println("IN setCurrentUser, YourFavoritesController - User ID: " + this.currentUser.getUser_id());
        loadFavoriteRecipes();
    }


}
