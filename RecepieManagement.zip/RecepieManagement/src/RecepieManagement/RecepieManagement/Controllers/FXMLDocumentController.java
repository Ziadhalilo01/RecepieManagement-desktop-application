package RecepieManagement.Controllers;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import java.net.URL;
import java.util.ResourceBundle;

public class FXMLDocumentController implements Initializable {
    @FXML
    private Label label;

    @FXML
    private BorderPane mainPane;


    @FXML
    private HBox RecipLayout;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {



    }
}
