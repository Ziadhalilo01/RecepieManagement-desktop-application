package RecepieManagement.Controllers;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class CaloriesForRecipeController {
    @FXML
    private TextField searchTextField;

    @FXML
    private VBox resultsVBox;

    @FXML
    private ImageView search;

    @FXML
    private Button searchButton;

    private double getNutrientValue(JsonObject nutrients, String key) {
        if (nutrients.has(key) && !nutrients.get(key).isJsonNull()) {
            return nutrients.get(key).getAsDouble();
        }
        return 0.0;
    }
    @FXML
    public void searchRecipes() {

        OkHttpClient client = new OkHttpClient.Builder()
                .readTimeout(30, TimeUnit.SECONDS)
                .connectTimeout(30, TimeUnit.SECONDS)
                .build();;

        String rapidApiKey = "70a7e9d646msh1390870405bd41cp1fe75ajsn102d61a49923";

        String input = searchTextField.getText().trim();


        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://edamam-food-and-grocery-database.p.rapidapi.com/api/food-database/v2/parser").newBuilder();
        urlBuilder.addQueryParameter("app_key", "6be02e9ac64cf47967bb50803dceafa0");
        urlBuilder.addQueryParameter("app_id", "cec73a13");
        urlBuilder.addQueryParameter("ingr", input);

        String url = urlBuilder.build().toString();

        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("X-RapidAPI-Key", rapidApiKey)
                .addHeader("X-RapidAPI-Host", "edamam-food-and-grocery-database.p.rapidapi.com")
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                showError("Request failed: " + response.code());
            } else {
                String responseBody = response.body().string();
                Gson gson = new Gson();
                JsonObject jsonResponse = gson.fromJson(responseBody, JsonObject.class);
                JsonArray hints = jsonResponse.getAsJsonArray("hints");

                resultsVBox.getChildren().clear();

                for (JsonElement hintElement : hints) {
                    JsonObject hint = hintElement.getAsJsonObject();
                    JsonObject food = hint.getAsJsonObject("food");
                    String label = food.get("label").getAsString();

                    String imageUrl = null;
                    if (food.has("image") && !food.get("image").isJsonNull()) {
                        imageUrl = food.get("image").getAsString();
                    }

                    if (imageUrl != null && !imageUrl.isEmpty()) {
                        ImageView imageView = new ImageView();
                        imageView.setFitWidth(125);
                        imageView.setFitHeight(125);
                        imageView.setImage(new Image(imageUrl, true));

                        JsonObject nutrients = food.getAsJsonObject("nutrients");
                        double calories = getNutrientValue(nutrients, "ENERC_KCAL");
                        double procnt = getNutrientValue(nutrients, "PROCNT");
                        double fat = getNutrientValue(nutrients, "FAT");
                        double chocdf = getNutrientValue(nutrients, "CHOCDF");
                        double fibtg = getNutrientValue(nutrients, "FIBTG");

                        HBox resultRow = new HBox(10);

                        VBox detailsVBox = new VBox(5);
                        Label foodLabel = new Label("Food: " + label);
                        foodLabel.setStyle("-fx-text-fill: white;");
                        Label caloriesLabel = new Label("Calories: " + calories);
                        caloriesLabel.setStyle("-fx-text-fill: white;");
                        Label proteinLabel = new Label("Protein: " + procnt);
                        proteinLabel.setStyle("-fx-text-fill: white;");
                        Label fatLabel = new Label("Fat: " + fat);
                        fatLabel.setStyle("-fx-text-fill: white;");
                        Label carbsLabel = new Label("Carbohydrates: " + chocdf);
                        carbsLabel.setStyle("-fx-text-fill: white;");
                        Label fiberLabel = new Label("Fiber: " + fibtg);
                        fiberLabel.setStyle("-fx-text-fill: white;");

                        detailsVBox.getChildren().addAll(
                                foodLabel,
                                caloriesLabel,
                                proteinLabel,
                                fatLabel,
                                carbsLabel,
                                fiberLabel
                        );

                        resultRow.getChildren().addAll(imageView, detailsVBox);
                        resultsVBox.getChildren().add(resultRow);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            showError("Error: " + e.getMessage());
        }
    }

    private void showError(String message) {
        Label errorLabel = new Label(message);
        errorLabel.setStyle("-fx-text-fill: red;");
        resultsVBox.getChildren().clear();
        resultsVBox.getChildren().add(errorLabel);
    }



    public void initialize() {
        search.toBack();
        searchButton.toFront();



    }
}
