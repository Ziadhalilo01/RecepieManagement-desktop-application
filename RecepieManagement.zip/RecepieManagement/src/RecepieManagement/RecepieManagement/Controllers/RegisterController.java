package RecepieManagement.Controllers;

import RecepieManagement.SwitchScenes.Logout_to_Login;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class RegisterController implements Initializable {

   @FXML
    TextField tf_r_username;

   @FXML
   TextField tf_r_userpassword;

   @FXML
   Button register_button1;

   @FXML
   Button back_to_login;

   @FXML
   TextField tf_r_useremail;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        register_button1.setOnAction(actionEvent -> {
            if(!tf_r_username.getText().trim().isEmpty() && !tf_r_userpassword.getText().trim().isEmpty()){
                Logout_to_Login.register(actionEvent,tf_r_username.getText(),
                        tf_r_userpassword.getText(),tf_r_useremail.getText());


            }else{
                System.out.println("Please fill out the username and password");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Please fill out all the textfields to register");
                alert.show();
            }
        });

        back_to_login.setOnAction(actionEvent -> Logout_to_Login.changeScene(actionEvent, "/RecepieManagement/views/LOGIN_and_REGISTER/loginPage.fxml","Log in!",null,-1));
    }
}
