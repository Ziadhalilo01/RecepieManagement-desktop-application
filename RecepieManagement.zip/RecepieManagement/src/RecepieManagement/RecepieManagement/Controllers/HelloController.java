package RecepieManagement.Controllers;
import RecepieManagement.FXML_Loader;
import RecepieManagement.SwitchScenes.Logout_to_Login;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    @FXML
    private Button logout_button;

    @FXML
    private Label welcome;

    @FXML
    BorderPane mainpanes;



    public String S;

    private int userId;


    public void setUserId(int userId) {
        this.userId = userId;
    }
    @FXML
    public void handleButton1Action() {

        this.S = "CategoryScene";
        System.out.println("You clicked me");
        FXML_Loader obj = new FXML_Loader();

        Pane view = obj.getView(S);

        mainpanes.setCenter(view);




    }

    @FXML
    public void handleButton2Action() {

        this.S = "DietInterface";

        System.out.println("You clicked me");
        FXML_Loader obj = new FXML_Loader();
        Pane view = obj.getView(S);
        mainpanes.setCenter(view);
    }

    @FXML
    public void handleButton3Action() {
        this.S = "FavoritesScene";
        System.out.println("You clicked me");
        FXML_Loader obj = new FXML_Loader();
        Pane view = obj.getView(S);
        mainpanes.setCenter(view);
    }

    @FXML
    public void handleButton4Action() {
        this.S = "CaloriesForRecipes";
        System.out.println("You clicked me");
        FXML_Loader obj = new FXML_Loader();
        Pane view = obj.getView(S);
        mainpanes.setCenter(view);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        logout_button.setOnAction(actionEvent -> Logout_to_Login.changeScene(actionEvent, "/RecepieManagement/views/LOGIN_and_REGISTER/loginPage.fxml","login",null,userId));

    }

    public void setUserInformation(String username){
        welcome.setText(" ");
    }
}