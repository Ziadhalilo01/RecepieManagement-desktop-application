package RecepieManagement.Controllers;

import RecepieManagement.Classes.user;
import RecepieManagement.SwitchScenes.Logout_to_Login;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML
    private TextField tf_username;

    @FXML
    private TextField tf_userpassword;

    user users;
    @FXML
    private Button login_button;

    @FXML
    private Button register_button;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        login_button.setOnAction(actionEvent -> {
            user loggedInUser = Logout_to_Login.loginuser(actionEvent, tf_username.getText(), tf_userpassword.getText());


            if (loggedInUser != null) {
                RecipyCardController recipyCardController = new RecipyCardController();
                recipyCardController.setUsers(loggedInUser);
                YourFavoritesController yourFavoritesController = new YourFavoritesController(loggedInUser);
                System.out.println("hi  "+loggedInUser.getUser_id());

            } else {

            }
        });
        register_button.setOnAction(actionEvent -> Logout_to_Login.changeScene(actionEvent, "/RecepieManagement/views/LOGIN_and_REGISTER/registerPage.fxml","Sign Up!",null,-1));
    }
}
