package RecepieManagement.Controllers;
import RecepieManagement.Classes.Recipe;
import RecepieManagement.Classes.user;
import RecepieManagement.mainApplication;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.layout.HBox;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CategoryController implements Initializable {
    @FXML
    private HBox RecipLayout;



    @Override
    public void initialize(URL url, ResourceBundle rb) {

        List<Node> recipeCards = new ArrayList<>();

        try (Connection conn = DriverManager.
                getConnection("jdbc:mysql://localhost:3306/recepiemanagement", "root", "root");

             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM recipes")) {

            while (rs.next()) {
                FXMLLoader loader = new FXMLLoader(FXMLDocumentController.class.
                        getResource("/RecepieManagement/RecipyCard.fxml"));

                Parent recipeCard = loader.load();

                RecipyCardController recipeCardController = loader.getController();
                Recipe recipe = new Recipe();
                recipe.setRecipe_id(rs.getInt("recipy_id"));
                recipe.setRecipe_name(rs.getString("recipy_name"));
                recipe.setInstructions(rs.getString("instructions"));
                recipe.setCooking_time(rs.getInt("cooking_time"));
                byte[] imageBytes = rs.getBytes("recipy_image");
                recipe.setRecipe_image(imageBytes);
                recipeCardController.setRecipy(recipe, mainApplication.getCurrentUser());
                recipeCards.add(recipeCard);

            }

        } catch (SQLException | IOException | NullPointerException e) {
            e.printStackTrace();
        }

        RecipLayout.getChildren().addAll(recipeCards);
    }
}