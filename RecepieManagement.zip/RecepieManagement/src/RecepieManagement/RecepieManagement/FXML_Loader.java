package RecepieManagement;

import RecepieManagement.mainApplication;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;

import java.net.URL;



public class FXML_Loader {
    private Pane view;

    public Pane getView(String filename) {
        try {

            URL fileURL = mainApplication.class.getResource("/RecepieManagement/" + filename +".fxml");
            if(fileURL == null) {
                throw new java.io.FileNotFoundException("File not found");
            }
            new FXMLLoader();
            view = FXMLLoader.load(fileURL);

        }catch(Exception e){
            System.out.println("No such file: " + filename + "please check your fxml folder");
        }
        return view;
    }
}
