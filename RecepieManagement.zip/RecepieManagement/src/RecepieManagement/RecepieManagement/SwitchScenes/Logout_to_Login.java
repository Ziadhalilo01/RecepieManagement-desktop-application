package RecepieManagement.SwitchScenes;
import RecepieManagement.Classes.user;
import RecepieManagement.Controllers.HelloController;
import RecepieManagement.mainApplication;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.*;


public class Logout_to_Login {



    public static void changeScene(ActionEvent event, String fxmlfile, String title, String username, int userID){
        Parent root = null;

        if(username != null){
            try{
                FXMLLoader loader = new FXMLLoader(Logout_to_Login.class.getResource(fxmlfile));
                root = loader.load();

                HelloController helloController = loader.getController();
                helloController.setUserInformation(username);
                helloController.setUserId(userID);

            }catch (IOException e){
                e.printStackTrace();

            }
        }else{
            try{
                root = FXMLLoader.load(Logout_to_Login.class.getResource(fxmlfile));
            }catch (IOException e){
                e.printStackTrace();
            }
        }

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle(title);
        stage.setScene(new Scene(root));
        stage.show();
    }

    public static void register(ActionEvent event,String username,String userpassword,String email) {
        Connection connection = null;
        PreparedStatement psInsert;
        PreparedStatement psCheckUserExists = null;
        ResultSet rs = null;
        user registeredUser = null; // Initialize the user object as null

        try{
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/recepiemanagement","root",
                    "root");
            psCheckUserExists = connection.prepareStatement("SELECT * FROM users WHERE username = ?");
            psCheckUserExists.setString(1,username);
            rs = psCheckUserExists.executeQuery();

            if(rs.isBeforeFirst()){
                System.out.println("User already exists!");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("You cannot use this username");
                alert.show();
            }else{
                psInsert = connection.prepareStatement("INSERT INTO users (username, userpassword, email) VALUES(?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
                psInsert.setString(1,username);
                psInsert.setString(2,userpassword);
                psInsert.setString(3,email);
                psInsert.executeUpdate();

                int userId = -1;
                ResultSet generatedKeys = psInsert.getGeneratedKeys();
                if (generatedKeys.next()) {
                    userId = generatedKeys.getInt(1);
                }

                registeredUser = new user(); // Create a new user object
                registeredUser.setUser_id(userId);
                mainApplication.setCurrentUser(registeredUser);
                System.out.println("register"+registeredUser.getUser_id());

                changeScene(event, "/RecepieManagement/views/hello-view.fxml", "Welcome!", username, userId);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            if(rs != null){
                try {
                    rs.close();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }
            if(psCheckUserExists != null){
                try{
                    psCheckUserExists.close();

                }catch (SQLException e){
                    e.printStackTrace();
                }
            }

            if(connection != null){
                try {
                    connection.close();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }
        }
    }


    public static user loginuser(ActionEvent event, String username, String userpassword) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        user loggedInUser = null;

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/recepiemanagement", "root",
                    "root");
            preparedStatement = connection.prepareStatement("SELECT user_id, userpassword FROM users WHERE username = ?");
            preparedStatement.setString(1, username);
            rs = preparedStatement.executeQuery();

            if (!rs.isBeforeFirst()) {
                System.out.println("User not found");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Provided infos are not available");
                alert.show();
            } else {

                while (rs.next()) {
                    int userId = rs.getInt("user_id");
                    user users = new user();
                    users.setUser_id(userId);
                    mainApplication.setCurrentUser(users);
                    System.out.println("login"+users.getUser_id());
                    String retrievePassword = rs.getString("userpassword");
                    if (retrievePassword.equals(userpassword)) {
                        loggedInUser = users;
                        changeScene(event, "/RecepieManagement/views/hello-view.fxml", "Welcome", username, userId);
                    } else {
                        System.out.println("Password did not match!");
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setContentText("The provided info is not found");
                        alert.show();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return loggedInUser;
    }






}
