package RecepieManagement.DBConnection;


import RecepieManagement.Classes.Recipe;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBHandler {
    private static DBHandler instance;
    private final String url = "jdbc:mysql://localhost:3306/recepiemanagement";

    private DBHandler() {
        connect();
    }

    public static synchronized DBHandler getInstance() {
        if (instance == null) {
            instance = new DBHandler();
        }
        return instance;
    }

    private Connection connect() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url,"root","root");
            System.out.println("Database connected successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public boolean doesUserExist(int userId) {
        String query = "SELECT * FROM users WHERE user_id = ?";
        try (Connection connection = this.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean doesRecipeExist(int recipeId) {
        String query = "SELECT * FROM recipes WHERE recipy_id = ?";
        try (Connection connection = this.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, recipeId);
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void addFavorite(int userId, int recipeId) {
        System.out.println(userId + ": " + recipeId);
        if (doesUserExist(userId) && doesRecipeExist(recipeId)) {
            String query = "INSERT INTO favorites (user_id, recipy_id) VALUES (?, ?)";
            try (Connection connection = this.connect();
                 PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, userId);
                preparedStatement.setInt(2, recipeId);
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public List<Recipe> getFavoriteRecipesForUser(int userId) {
        String query = "SELECT * FROM recipes JOIN favorites ON recipes.recipy_id = favorites.recipy_id WHERE favorites.user_id = ?";
        List<Recipe> recipes = new ArrayList<>();
        try (Connection connection = this.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Recipe recipe = new Recipe();
                recipe.setRecipe_id(resultSet.getInt("recipy_id"));
                recipe.setRecipe_name(resultSet.getString("recipy_name"));
                recipe.setCooking_time(resultSet.getInt("cooking_time"));
                recipe.setInstructions(resultSet.getString("instructions"));
                recipe.setRecipe_image(resultSet.getBytes("recipy_image"));
                recipes.add(recipe);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return recipes;
    }

    public boolean isRecipeInFavorites(int userId, int recipeId) {
        String query = "SELECT * FROM favorites WHERE user_id = ? AND recipy_id = ?";
        try (Connection connection = this.connect();
                PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, recipeId);
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void removeFavorite(int userId, int recipeId) {
        String query = "DELETE FROM favorites WHERE user_id = ? AND recipy_id = ?";
        try (Connection connection = this.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, recipeId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
