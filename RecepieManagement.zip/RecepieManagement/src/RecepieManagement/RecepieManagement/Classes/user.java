package RecepieManagement.Classes;

public class user {
    private int user_id;
    private String username;
    private String userpassword;
    private String email;


    public user() {}

    public user(int user_id,String username,String userpassword, String email) {
        this.user_id = user_id;
        this.userpassword = userpassword;
        this.username = username;
        this.email = email;

    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }


    public String getUserpassword() {
        return userpassword;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }


}
