package RecepieManagement.Classes;



import java.util.List;

public class RecipeSearchResponse {
    public List<Hit> hits;

    public static class Hit {
        public Recipy recipy;
    }

    public static class Recipy {
        public String label;
        public String image;
        public String url;
        public List<String> dietLabels;
        public List<String> healthLabels;
        public List<String> cautions;
        public List<Ingredient> ingredients;
        public double calories;
        public double totalWeight;

        public static class Ingredient {
            public String text;
            public double weight;
        }
    }
}