package RecepieManagement.Classes;


public class Recipe {
    private int recipy_id;
    private String recipy_name;
    private String instructions;
    private int cooking_time;
    private byte[] recipy_image;

    public Recipe() {}

    public Recipe(int recipe_id, String recipe_name, String instructions, int cooking_time, byte[] recipe_image) {
        this.recipy_id = recipe_id;
        this.recipy_name = recipe_name;
        this.instructions = instructions;
        this.cooking_time = cooking_time;
        this.recipy_image = recipe_image;
    }

    public int getRecipe_id() {
        return recipy_id;
    }

    public void setRecipe_id(int recipe_id) {
        this.recipy_id = recipe_id;
    }

    public String getRecipe_name() {
        return recipy_name;
    }

    public void setRecipe_name(String recipe_name) {
        this.recipy_name = recipe_name;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public int getCooking_time() {
        return cooking_time;
    }

    public void setCooking_time(int cooking_time) {
        this.cooking_time = cooking_time;
    }

    public byte[] getRecipe_image() {
        return recipy_image;
    }

    public void setRecipe_image(byte[] recipe_image) {
        this.recipy_image = recipe_image;
    }
}